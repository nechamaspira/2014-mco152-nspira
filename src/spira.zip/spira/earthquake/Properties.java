package spira.earthquake;

public class Properties {

	private String place;
	private double mag;
	
	public Properties(){
		
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public double getMag() {
		return mag;
	}

	public void setMag(double mag) {
		this.mag = mag;
	}
}
