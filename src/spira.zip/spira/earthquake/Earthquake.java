package spira.earthquake;

public class Earthquake {

	private Features [] features;

	public Features[] getFeatures() {
		return features;
	}

	
}
