package spira.earthquake;

public class Features {

	private Properties properties;

	public Properties getBla() {
		return properties;
	}

	public void setBla(Properties all) {
		this.properties = all;
	}

}	


