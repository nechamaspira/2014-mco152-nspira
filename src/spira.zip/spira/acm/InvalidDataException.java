package spira.acm;

public class InvalidDataException extends Exception {
	public InvalidDataException() {
		super("invalid data");
	}
}
