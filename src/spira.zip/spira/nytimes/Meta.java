package spira.nytimes;

public class Meta {

	private int hits;
	private double time;
	private int offset;
	
	public int getHits() {
		return hits;
	}
	public double getTime() {
		return time;
	}
	public int getOffset() {
		return offset;
	}
}
