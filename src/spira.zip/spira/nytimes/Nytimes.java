package spira.nytimes;

public class Nytimes {
	private Response response;

	public Response getResponse() {
		return response;
	}

}
