package spira.nytimes;

public class HeadLine {
	private String main;
	//private String content_kicker;
	//private String kicker;

	public String getMain() {
		return main;
	}

	
}
