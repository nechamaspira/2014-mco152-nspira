package spira.tetris;

public class Square {

	
}
