package spira.tetris;

public class Board {

	private Square squares [][];
	
	public void Board(){
		squares = new Square[20][10];
	}
	
	
	
}
