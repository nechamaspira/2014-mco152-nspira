package spira.tetris;

public class Piece {
	
	protected Square [][] squares;
	
	public Piece(){
		//Square = new Square[4][4];
	}
	public void moveRight(){
		
	}
	public void moveLeft(){
		
	}
	public void moveDown(){
		
	}
	public void rotateRight(){
		//do this
	}
	public String toString(){
		return null;
		
	}

}

//pieces - box , line ,l,t , j,s,z all ending with piece