package spira.tetris;

public class LinePiece extends Piece{

	
	public LinePiece(){
		super();
		
		//squares[][] = new Square();
		
	}
}
