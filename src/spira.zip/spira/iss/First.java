package spira.iss;

public class First {
	
	private Results [] results;

	public Results [] getResults() {
		return results;
	}

}
