package spira.iss;

public class GetInfo {

	private Response[] response;

	public Response[] getResponse() {
		return response;
	}

	
}
