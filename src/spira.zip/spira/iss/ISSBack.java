package spira.iss;

public class ISSBack {

	private Response[] response;

	public Response[] getResponse() {
		return response;
	}

}
