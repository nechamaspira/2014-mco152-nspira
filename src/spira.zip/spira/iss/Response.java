package spira.iss;

public class Response {

	private long risetime;
	
	public long getRisetime() {
		return risetime;
	}
	
}
